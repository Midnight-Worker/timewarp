/*
 * Einen Termin in der Woche wie ein Rechteck aufziehen.
 *
 * Zeiger auf freiem Tagesfeld drücken und über mehrere Tage ziehen.
 * Das Ergebnis ist ein Termin von 00:00 Uhr am ersten gewählten Tag
 * bis 00:00 Uhr nach dem letzten gewählten Tag.
 */

const WEEK_COLUMN_LEFT = 65;
const WEEK_COLUMN_WIDTH = 313;
const WEEK_COLUMN_TOP = 270;
const WEEK_COLUMN_BOTTOM = 1275;

function weekDayIndexAt(worldPoint) {
    if (currentViewLevel !== 4) {
        return null;
    }

    if (worldPoint.y < WEEK_COLUMN_TOP || worldPoint.y > WEEK_COLUMN_BOTTOM) {
        return null;
    }

    const dayIndex = Math.floor((worldPoint.x - WEEK_COLUMN_LEFT) / WEEK_COLUMN_WIDTH);

    if (dayIndex < 0 || dayIndex > 6) {
        return null;
    }

    return dayIndex;
}

function startDrawingWeekAppointment(worldPoint) {
    const dayIndex = weekDayIndexAt(worldPoint);

    if (dayIndex === null) {
        return false;
    }

    weekDrawingSession = {
        firstDayIndex: dayIndex,
        lastDayIndex: dayIndex,
        preview: null
    };

    return true;
}

function updateWeekDrawing(worldPoint) {
    if (!weekDrawingSession) {
        return;
    }

    const dayIndex = weekDayIndexAt(worldPoint);

    if (dayIndex !== null) {
        weekDrawingSession.lastDayIndex = dayIndex;
    }

    drawWeekSelectionRectangle();
}

function drawWeekSelectionRectangle() {
    if (!weekDrawingSession) {
        return;
    }

    if (weekDrawingSession.preview) {
        weekDrawingSession.preview.remove();
    }

    const firstDay = Math.min(
        weekDrawingSession.firstDayIndex,
        weekDrawingSession.lastDayIndex
    );
    const lastDay = Math.max(
        weekDrawingSession.firstDayIndex,
        weekDrawingSession.lastDayIndex
    );
    const rectangleLeft = WEEK_COLUMN_LEFT + firstDay * WEEK_COLUMN_WIDTH + 7;
    const rectangleWidth = (lastDay - firstDay + 1) * WEEK_COLUMN_WIDTH - 14;

    weekDrawingSession.preview = createSvgElement('rect', {
        x: rectangleLeft,
        y: WEEK_COLUMN_TOP,
        width: rectangleWidth,
        height: 170,
        rx: 12,
        fill: '#75f0d2',
        'fill-opacity': 0.17,
        stroke: '#a5ffe0',
        'stroke-width': 5,
        'stroke-dasharray': '14 10',
        'pointer-events': 'none'
    });
}

function finishDrawingWeekAppointment(wasDragged) {
    const drawing = weekDrawingSession;
    weekDrawingSession = null;

    if (!drawing) {
        return false;
    }

    if (drawing.preview) {
        drawing.preview.remove();
    }

    // Ein Klick bleibt ein Klick: nur Ziehen legt einen Zeitraum an.
    if (!wasDragged) {
        return false;
    }

    const firstDayIndex = Math.min(drawing.firstDayIndex, drawing.lastDayIndex);
    const lastDayIndex = Math.max(drawing.firstDayIndex, drawing.lastDayIndex);
    const weekMonday = startOfWeek(selectedDate);
    const firstDate = addDays(weekMonday, firstDayIndex);
    const dayAfterLast = addDays(weekMonday, lastDayIndex + 1);

    const startTime = convertLocalTimeToUtc(
        firstDate.getFullYear(), firstDate.getMonth() + 1, firstDate.getDate(),
        0, 0, homeTimeZone
    );
    const endTime = convertLocalTimeToUtc(
        dayAfterLast.getFullYear(), dayAfterLast.getMonth() + 1,
        dayAfterLast.getDate(), 0, 0, homeTimeZone
    );

    const newAppointment = {
        id: Date.now() + Math.random(),
        title: 'Neuer Zeitraum',
        at: new Date(startTime).toISOString(),
        duration: Math.round((new Date(endTime) - new Date(startTime)) / 60000),
        owner: 'me'
    };

    appointments.push(newAppointment);
    selectAppointment(newAppointment);
    saveAppointments();
    renderCurrentScene();
    openAppointmentEditor(newAppointment);
    return true;
}
