/* Wochenansicht und Aufgaben */

/** Sieben Kalendertage nebeneinander mit verschiebbaren Terminkarten. */
function renderWeekView() {
    const monday = startOfWeek(selectedDate);
    const weekSheet = createSvgElement('g');

    drawSvgRectangle(
        weekSheet, 0, 0, 2260, 1470,
        '#112f42', '#649fa9', {
            'stroke-width': 6,
            filter: 'url(#shadow)'
        }
    );

    drawSvgText(
        weekSheet, 65, 96,
        `Woche · ${monday.toLocaleDateString('de-DE')}`,
        68, '#a5ffe0', 800
    );
    drawSvgText(
        weekSheet, 69, 145,
        'Alle Kalender · Karten direkt bearbeiten', 23, '#b0d3dd'
    );

    for (let dayIndex = 0; dayIndex < 7; dayIndex++) {
        const date = addDays(monday, dayIndex);
        drawWeekDayColumn(weekSheet, date, dayIndex);
    }
    drawWeekRangeBars(weekSheet, monday);
}

function drawWeekDayColumn(weekSheet, date, dayIndex) {
    const dateKey = formatLocalDate(date);
    const dayColumnLeft = 65 + dayIndex * 313;
    const dayGroup = createSvgElement('g', {
        'data-date': dateKey,
        style: 'cursor:pointer'
    }, weekSheet);

    drawSvgRectangle(
        dayGroup, dayColumnLeft, 196, 296, 1190,
        dayIndex % 2 ? '#18394d' : '#194257',
        '#41687b', { 'stroke-width': 2 }
    );

    const dateLabel =
        `${weekdayAbbreviations[date.getDay()]} ` +
        `${date.getDate()}.${date.getMonth() + 1}.`;

    drawSvgText(dayGroup, dayColumnLeft + 18, 247, dateLabel, 28, '#f0ffff', 700);

    const visibleAppointments = appointmentsForDate(dateKey)
        .filter(appointment => visibleTeamMemberIds.has(appointment.owner))
        .slice(0, 14);

    visibleAppointments.forEach((appointment, index) => {
        const appointmentTop = 282 + index * 77;
        renderAppointmentCard(dayGroup, appointment, dayColumnLeft + 12, appointmentTop, 270, 69);
    });
}


/** Mehrtägige Termine erscheinen als durchgehende Streifen am unteren Rand. */
function drawWeekRangeBars(parent, monday) {
    const weekStart = formatLocalDate(monday);
    const weekEnd = formatLocalDate(addDays(monday, 6));

    for (const appointment of appointments) {
        const start = appointmentUtcDate(appointment);
        const end = new Date(start.getTime() + appointment.duration * 60000);
        const startKey = dateStringInTimeZone(start, homeTimeZone);
        const endKey = dateStringInTimeZone(new Date(end.getTime() - 1), homeTimeZone);
        if (endKey < weekStart || startKey > weekEnd) {
            continue;
        }

        const visibleStart = startKey < weekStart ? weekStart : startKey;
        const visibleEnd = endKey > weekEnd ? weekEnd : endKey;
        const startIndex = Math.round(
            (new Date(visibleStart + 'T12:00:00') - new Date(weekStart + 'T12:00:00'))
            / 86400000
        );
        const endIndex = Math.round(
            (new Date(visibleEnd + 'T12:00:00') - new Date(weekStart + 'T12:00:00'))
            / 86400000
        );
        const ownerIndex = teamMemberOrder.indexOf(appointment.owner);
        const left = 65 + startIndex * 313 + 10;
        const width = (endIndex - startIndex + 1) * 313 - 20;
        const top = 1293 + ownerIndex * 18;
        const group = createSvgElement('g', {'data-card': appointment.id}, parent);
        drawSvgRectangle(group, left, top, width, 13, findTeamMember(appointment.owner).color);
    }
}
